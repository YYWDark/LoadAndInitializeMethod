//
//  ViewController.m
//  LoadAndInitializeMethod
//
//  Created by wyy on 2016/12/5.
//  Copyright © 2016年 wyy. All rights reserved.
//

#import "ViewController.h"
#import "Student.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
          NSLog(@"%@ %s 当前的线程：%@", [self class], __FUNCTION__,[NSThread currentThread]);
          Student *Student1 = [[Student alloc] init];
          Student *Student2 = [[Student alloc] init];
    });
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
