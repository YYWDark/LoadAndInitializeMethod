//
//  Person+Extension.h
//  LoadAndInitializeMethod
//
//  Created by wyy on 2016/12/5.
//  Copyright © 2016年 wyy. All rights reserved.
//

#import "Person.h"

@interface Person (Extension)

@end
