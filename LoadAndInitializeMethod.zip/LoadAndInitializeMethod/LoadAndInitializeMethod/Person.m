//
//  Person.m
//  LoadAndInitializeMethod
//
//  Created by wyy on 2016/12/5.
//  Copyright © 2016年 wyy. All rights reserved.
//

#import "Person.h"

@implementation Person
//+ (void)load{
//    NSLog(@"Person类调用了load method");
//}

+ (void)initialize{
    NSLog(@"%@ %s 当前的线程：%@", [self class], __FUNCTION__,[NSThread currentThread]);
    NSLog(@"Person类调用了initialize method");
}
@end
