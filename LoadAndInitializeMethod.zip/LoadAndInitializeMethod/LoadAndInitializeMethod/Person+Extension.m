//
//  Person+Extension.m
//  LoadAndInitializeMethod
//
//  Created by wyy on 2016/12/5.
//  Copyright © 2016年 wyy. All rights reserved.
//

#import "Person+Extension.h"
#import <objc/objc-runtime.h>
@implementation Person (Extension)
//+ (void)load{
//    NSLog(@"Person分类调用load method");
//}


/*
 load method:
 当一个类或者该类的分类被加入Objective-C 运行时的时候被调用。
 
 注意：
 1.类本身的load方法在他的父类们调用load method结束以后
 2.分类的load method 在类本身load method 之后调用
 3.不同类的调用顺序是不确定的
 
 1.不要在load方法对其它类做操作，因为没法去判断该类是否已经load完成
 2.load 方法里面尽量精简些  因为在主线程所以会阻塞
 3.一般用作调试。比如在分类里编写该方法，用来判断该分类是否正确载入系统中
 4.不遵循继承规则
*/

/*
 initialize:
 1.在类初始化第一次的时候调用，不管初始化多少次只调用一次。你可以想象成懒加载模式
 2.该方法调用的线程就是类初始化的线程
 4.遵循继承规则
 */
@end
