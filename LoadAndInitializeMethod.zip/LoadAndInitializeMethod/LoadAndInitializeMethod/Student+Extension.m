//
//  Student+Extension.m
//  LoadAndInitializeMethod
//
//  Created by wyy on 2016/12/5.
//  Copyright © 2016年 wyy. All rights reserved.
//

#import "Student+Extension.h"

@implementation Student (Extension)
//+ (void)load{
//    NSLog(@"Student分类调用load method");
//}
@end
